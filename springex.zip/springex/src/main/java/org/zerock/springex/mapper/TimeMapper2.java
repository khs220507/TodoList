package org.zerock.springex.mapper;

public interface TimeMapper2 {
    String getNow();
}

